from botcity.web import Browser
from webdriver_manager.chrome import ChromeDriverManager
import undetected_chromedriver as undetected

def configurar_indetectavel(wbot):

    """
    
    Prepara Chrome para a execução indetectavel.

    ->
    wbot: Instância do web bot ativa.
    
    """

    options = undetected.ChromeOptions()
    options.headless=True
    #options.add_argument(f"user-data-dir='C:\\Users\\bot-python-01\\AppData\\Local\\Google\\Chrome\\User Data\\'")
    #options.add_argument("--disable-blink-features=AutomationControlled") 
    #options.add_argument("--start-maximized") 
    #options.add_argument("--lang=en-US") 
    #.add_argument("--disable-extensions") 

    arguments = [
        "--ignore-certificate-errors", "--remote-allow-origins=*", "--no-first-run",
        "--no-service-autorun", "--no-default-browser-check", "--homepage=about:blank",
        "--kiosk-printing", "--password-store=basic", "--no-pings",
        "--disable-infobars", "--disable-component-update",
        "--disable-breakpad", "--disable-backgrounding-occluded-windows", "--disable-renderer-backgrounding",
        "--disable-background-networking", "--disable-blink-features=AutomationControlled",
        "--disable-features=IsolateOrigins,site-per-process", "--disable-dev-shm-usage",
        "--disable-session-crashed-bubble", "--disable-search-engine-choice-screen", "--enable-geolocation"
    ]

    for argument in arguments:

        options.add_argument(argument)

    # Definindo caminho do Driver
    wbot.driver_path = undetected.Chrome(executable_path = ChromeDriverManager().install(),options=options).service.path

    # Definindo navegador como Chrome
    wbot.browser = Browser.CHROME